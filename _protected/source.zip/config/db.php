<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=ppdsmk_mis',
    'username' => 'ppdsmk_mis',
    'password' => 'Ppdsmk_mis$',
    'charset' => 'utf8',
];