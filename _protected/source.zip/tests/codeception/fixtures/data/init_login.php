<?php

return [
    [
        // this user is active and is The Creator of the site
        'username' => 'The Creator',
        'email' => 'creator@example.com',
        'auth_key' => '8QcTRbD5UxYkaJ9calSahAvXd_GMPIcS',
        // password is : creator123
        'password_hash' => '$2y$13$joQ.0Gz.Kg1oST/BpkR1d.Ch5BjxW8NUGgJR1rvHXpNQtbRByW5k2',
        'password_reset_token' => '',
        'account_activation_token' => '',
        'status' => 10,
        'created_at' => '1413919102',
        'updated_at' => '1413919102',
    ],
    [
        // this user is active and is administrator of the site
        'username' => 'admin',
        'email' => 'admin@example.com',
        'auth_key' => 'XTXELOT8VKEojl4hpov-gT7Fj2Rs2MX-',
        // password is : admin123
        'password_hash' => '$2y$13$p42pDgFC67pKhLuP0HVFR.jZdBF1BwiQP0MLDf3GO8jfjo0MjoQyi',
        'password_reset_token' => 'geGUnapFHpJWdztNKS4nj4Eb404Q1il1_1412606184',
        'account_activation_token' => 'ttVzjequF5PNR8jsLDUczmJkxPuQMStl_' . time(),
        'status' => 10,
        'created_at' => '1413919102',
        'updated_at' => '1413919102',  
    ],
    [
        // this user is active and is member of the site
        'username' => 'member',
        'email' => 'member@example.com',
        'auth_key' => 'sjXnhU0Dpku3vZb3tTqxgtNBXUSOTLLU',
        // password is : member123
        'password_hash' => '$2y$13$4UkVY65btY8.uFsylJjq8O./fkoDJGQPASKOSW4.3D7RcbT8pvksm',
        'password_reset_token' => 'geGUnapFHpJWdztNKS4nj4Eb404Q1il1_1412606182',
        'account_activation_token' => 'afVzjequF5PNR8jsLDUczmJkxPuQMStl_' . time(),
        'status' => 10,
        'created_at' => '1413919102',
        'updated_at' => '1413919102',
    ],
    [
        // this user has not activated his account
        'username' => 'tester',
        'email' => 'tester@example.com',
        'auth_key' => 'AxCA1v9zj3183w1bttOIcsGGrvrwkm-u',
        // password is : test123
        'password_hash' => '$2y$13$L7u5zjs0hMHVuMWaJzt2MuOvsgpkpEqIW0ir9pcMAeK16zDPoHmJu',
        'password_reset_token' => '4BSNyiZNAuxjs5Mty990c47sVrgllIi_' . time(),
        'account_activation_token' => 'xqVzjequF5PNR8jsLDUczmJkxPuQMStl_' . time(),
        'status' => 1,
        'created_at' => '1413919102',
        'updated_at' => '1413919102',
    ],
];
