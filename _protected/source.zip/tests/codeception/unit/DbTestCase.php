<?php
namespace tests\codeception\unit;

/**
 * Class DbTestCase
 * 
 * @package tests\codeception\unit
 */
class DbTestCase extends \yii\codeception\DbTestCase
{
    public $appConfig = '@tests/codeception/config/unit.php';
}
