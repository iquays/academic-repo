<?php
namespace tests\codeception\unit;

/**
 * Class TestCase
 * @package tests\codeception\unit
 */
class TestCase extends \yii\codeception\TestCase
{
    public $appConfig = '@tests/codeception/config/unit.php';
}
