<?php

return [
    '{attribute} cannot be blank.' => 'le champ \'{attribute}\' ne peut être vide.',
    'The verification code is incorrect.' => 'La vérification du code est incorrecte.',
    'Home' => 'Accueil',
    'You are not allowed to perform this action.' => 'Vous n\'êtes pas autoriser à éxécuter cette action.'
];
