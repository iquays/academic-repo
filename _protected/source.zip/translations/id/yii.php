<?php

return [
    '{attribute} cannot be blank.' => 'Kolom {attribute} tidak boleh kosong.',
    'The verification code is incorrect.' => 'Kode verifikasi salah.',
    'Home' => 'Home',
    'You are not allowed to perform this action.' => 'Anda tidak diperbolehkan mengakses fitur ini.',
    '{attribute} must be a number.' => '{attribute} harus berupa angka.',
    '{attribute} must be an integer.' => '{attribute} harus berupa angka.',
    '{attribute} "{value}" has already been taken.' => '{attribute} "{value}" sudah digunakan.',

];